package com.muqing.android;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Movie;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

/**
 * 气泡背景：单一静态图片，或 GIF；双方共用同一张。
 *
 * 关键：它是 TextView 的 background，bounds 由 TextView 自己给。
 * 文字变长 → view 变宽 → bounds 变宽 → 这里按新 bounds 重画，
 * 所以气泡【随输出文字的长度（宽度）改变而改变】，不需要任何测量代码。
 *
 * 静态图按九宫格拉（四角不拉伸，边与中间拉伸），避免整张被拉糊。
 * GIF 用原生 Movie 逐帧绘制并整体缩放，不引任何第三方库。
 * 解不出来就返回 null，调用方回退到默认纯色气泡 —— 不塞兜底文案。
 */
public final class BubbleDrawable extends Drawable {
    private final Bitmap bitmap;
    private final Movie movie;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Runnable tick = new Runnable() {
        @Override public void run() { invalidateSelf(); }
    };

    private BubbleDrawable(Bitmap b, Movie m) { bitmap = b; movie = m; }

    /** 从文件构造。失败返回 null（调用方回退默认气泡）。 */
    public static BubbleDrawable from(String path, boolean gif) {
        if (path == null) return null;
        if (gif) {
            Movie m = Movie.decodeFile(path);
            return m == null ? null : new BubbleDrawable(null, m);
        }
        Bitmap b = BitmapFactory.decodeFile(path);
        return b == null ? null : new BubbleDrawable(b, null);
    }

    @Override public void draw(Canvas c) {
        Rect r = getBounds();
        if (r.width() <= 0 || r.height() <= 0) return;
        if (movie != null) {
            int dur = movie.duration();
            if (dur > 0) movie.setTime((int) (SystemClock.uptimeMillis() % dur));
            c.save();
            c.translate(r.left, r.top);
            c.scale((float) r.width() / Math.max(1, movie.width()),
                    (float) r.height() / Math.max(1, movie.height()));
            movie.draw(c, 0, 0);
            c.restore();
            scheduleSelf(tick, 40);      // 下一帧；不额外起线程、不常驻定时器
            return;
        }
        if (bitmap != null) drawNine(c, bitmap, r);
    }

    private void drawNine(Canvas c, Bitmap b, Rect d) {
        int w = b.getWidth(), h = b.getHeight();
        int cw = Math.max(1, Math.min(w / 3, 28));
        int ch = Math.max(1, Math.min(h / 3, 28));
        if (d.width() < 2 * cw || d.height() < 2 * ch) {
            // 太小就整张拉伸，仍随宽度变
            c.drawBitmap(b, new Rect(0, 0, w, h), d, paint);
            return;
        }
        int[] sx = {0, cw, w - cw, w};
        int[] sy = {0, ch, h - ch, h};
        int[] dx = {d.left, d.left + cw, d.right - cw, d.right};
        int[] dy = {d.top, d.top + ch, d.bottom - ch, d.bottom};
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                Rect src = new Rect(sx[i], sy[j], sx[i + 1], sy[j + 1]);
                Rect dst = new Rect(dx[i], dy[j], dx[i + 1], dy[j + 1]);
                if (!src.isEmpty() && !dst.isEmpty()) c.drawBitmap(b, src, dst, paint);
            }
        }
    }

    @Override public void setAlpha(int a) { paint.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { paint.setColorFilter(f); }
    @Override public int getOpacity() { return 0; }
}
