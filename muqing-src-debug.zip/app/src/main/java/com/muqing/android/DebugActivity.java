package com.muqing.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import com.muqing.R;

import java.util.List;

/**
 * 调试界面 —— 只有调试版有这个 Activity，正式版 Manifest 里不存在。
 *
 * 它是给检查的人看的壳，不是沐晴的界面：
 * 不显示"她现在怎样"作为状态、不进她的内部、不产生任何回复。
 * 显示的是已经发生过的事（时间、线程、标签、数值），不是预测或观测面板。
 *
 * 没有定时器、没有自动刷新：只在进入 / 点「刷新」时拉一次。
 * 她睡醒仍由她自己，不因为这个界面多醒一次。
 */
public final class DebugActivity extends Activity {
    private TextView body;
    private TextView meta;
    private Button filterBtn;
    private ScrollView scroll;

    private static final String[] FILTERS = { "ALL", "EV", "ST", "UI", "ERR" };
    private static final String[] LABELS  = { "全部", "事件", "状态", "界面", "异常" };
    private int idx;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_debug);
        body = (TextView) findViewById(R.id.debug_body);
        meta = (TextView) findViewById(R.id.debug_meta);
        filterBtn = (Button) findViewById(R.id.btn_filter);
        scroll = (ScrollView) findViewById(R.id.debug_scroll);

        ((View) findViewById(R.id.btn_back)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        ((View) findViewById(R.id.btn_refresh)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { render(); }
        });
        ((View) findViewById(R.id.btn_clear)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { DebugLog.clear(); render(); }
        });
        filterBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                idx = (idx + 1) % FILTERS.length;
                DebugLog.setFilter(FILTERS[idx]);
                filterBtn.setText(LABELS[idx]);
                render();
            }
        });
        filterBtn.setText(LABELS[idx]);
        DebugLog.write("UI", "打开调试日志界面");
        render();
    }

    @Override protected void onResume() { super.onResume(); render(); }

    private void render() {
        List<String> lines = DebugLog.recent(FILTERS[idx], 500);
        StringBuilder sb = new StringBuilder();
        if (lines.isEmpty()) {
            sb.append("（这个筛选下还没有日志。回聊天页说一句话，再回来点「刷新」。）");
        } else {
            for (String s : lines) sb.append(s).append('\n');
        }
        if (lines.size() == 500) sb.append("… 只显示最近 500 行，完整记录在 debug.log\n");
        body.setText(sb.toString());
        meta.setText(DebugLog.stats());
        scroll.post(new Runnable() {
            @Override public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
        });
    }
}
