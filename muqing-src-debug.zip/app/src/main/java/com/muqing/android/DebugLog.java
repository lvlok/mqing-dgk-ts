package com.muqing.android;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 调试日志落点：三条出口同时给，都不进她的任何空间。
 *
 *   ① logcat      —— tag = MuQing/XXX，给有电脑的人
 *   ② debug.log   —— 私有目录独立文件，MT 管理器能直接打开
 *   ③ 内存环形缓冲 —— 调试界面里直接翻（没电脑时最有用）
 *
 * 明确不是第四个空间：不写 muqing.state、不写 consequence.log、
 * 不写 chat.log；不被引擎读取、不参与选词、不改阈值、不驱动睡醒。
 * 只有用户手动点「清空」才会删，调试版不自动删。
 */
public final class DebugLog {
    public static final int MAX_LINES = 3000;

    private static final ArrayList<String> ring = new ArrayList<String>();
    private static File file;
    private static long boot;
    private static long seq;
    private static boolean ready;

    private DebugLog() { }

    public static synchronized void init(Context c) {
        if (ready) return;
        file = new File(c.getFilesDir(), "debug.log");
        boot = System.currentTimeMillis();
        ready = true;
        write("EV", "===== 调试版启动（正式版无此出口）=====");
    }

    /** 由 core 的 Debug.Sink 接进来。tag：EV 事件 / ST 内部状态 / UI 界面 / ERR 异常。 */
    public static synchronized void write(String tag, String msg) {
        long t = ready ? System.currentTimeMillis() - boot : 0;
        String line = String.format("[+%06d.%03d][#%d][%s][%s] %s",
                t / 1000, t % 1000, ++seq,
                Thread.currentThread().getName(), tag,
                msg == null ? "" : msg.replace("\n", " ⏎ ").replace("\r", ""));
        try { Log.d("MuQing/" + tag, msg == null ? "" : msg); } catch (Throwable ignored) { }
        ring.add(line);
        while (ring.size() > MAX_LINES) ring.remove(0);
        if (!ready || file == null) return;
        FileWriter w = null;
        try {
            w = new FileWriter(file, true);
            w.write(line);
            w.write('\n');
        } catch (IOException ignored) {
            // 日志写失败绝不影响她
        } finally {
            if (w != null) try { w.close(); } catch (IOException ignored) { }
        }
    }

    /** filter: ALL / EV / ST / UI / ERR。返回最近 max 条，按时间正序。 */
    public static synchronized List<String> recent(String filter, int max) {
        ArrayList<String> out = new ArrayList<String>();
        if (max <= 0) return out;
        for (int i = ring.size() - 1; i >= 0 && out.size() < max; i--) {
            String s = ring.get(i);
            if ("ALL".equals(filter) || s.contains("[" + filter + "] ")) out.add(s);
        }
        java.util.Collections.reverse(out);
        return out;
    }

    public static synchronized void clear() {
        ring.clear();
        if (file != null) try { new FileWriter(file, false).close(); } catch (IOException ignored) { }
        write("EV", "日志已手动清空（她的状态文件一个字节没动）");
    }

    public static synchronized String stats() {
        long size = (file != null && file.exists()) ? file.length() : 0;
        long sec = ready ? (System.currentTimeMillis() - boot) / 1000 : 0;
        return "行数 " + ring.size() + "/" + MAX_LINES
                + " · debug.log " + size + " B"
                + " · 已运行 " + sec + " s"
                + " · 当前筛选：" + (filterName == null ? "ALL" : filterName);
    }

    private static String filterName = "ALL";
    public static synchronized void setFilter(String f) { filterName = f; }
    public static synchronized String filter() { return filterName; }
}
