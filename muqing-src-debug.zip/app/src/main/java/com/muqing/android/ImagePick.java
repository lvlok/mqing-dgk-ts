package com.muqing.android;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** 选图落盘：复制到私有目录，重开也在。不申请外部存储权限。 */
public final class ImagePick {
    public static final int REQ_AVATAR_AI = 11;
    public static final int REQ_AVATAR_USER = 12;
    public static final int REQ_BG = 13;
    public static final int REQ_BUBBLE = 14;

    public static final String AVATAR_AI = "avatar_ai.img";
    public static final String AVATAR_USER = "avatar_user.img";
    public static final String BG = "bg.img";
    public static final String BUBBLE = "bubble.img";   // 内容可为 PNG/JPG 或 GIF

    private ImagePick() {}

    public static Intent pick() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        return i;
    }

    public static File file(Context c, String name) {
        return new File(c.getFilesDir(), name);
    }

    /** 返回是否成功落盘。失败就是没换，不提示、不追问。 */
    public static boolean copy(Context c, Uri uri, String name) {
        if (uri == null) return false;
        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = c.getContentResolver().openInputStream(uri);
            if (in == null) return false;
            out = new FileOutputStream(file(c, name));
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
            try { if (out != null) out.close(); } catch (Exception ignored) { }
        }
    }

    public static void clear(Context c, String name) { file(c, name).delete(); }

    /** GIF 按魔数判断，不看扩展名 —— 用户传上来的文件名不可信。 */
    public static boolean isGif(File f) {
        if (f == null || !f.exists()) return false;
        java.io.FileInputStream in = null;
        try {
            in = new java.io.FileInputStream(f);
            byte[] h = new byte[3];
            return in.read(h) == 3 && h[0] == 'G' && h[1] == 'I' && h[2] == 'F';
        } catch (Exception e) {
            return false;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
        }
    }
}
