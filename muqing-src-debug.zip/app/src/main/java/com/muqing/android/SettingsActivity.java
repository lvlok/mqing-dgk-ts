package com.muqing.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.muqing.R;

/**
 * 列表页：第一项是「显示」，点击展开副列表，其余项自然往下移。
 *
 * 不再给用户的界面：记忆层、后果层（留档）。那两个是 AI 自己的空间，
 * 列出来就破了「透明」这个阻塞项。
 *
 * 只留一个「清理聊天数据」：进入选择模式，删的是 chat.log 里的表面记录，
 * 不碰 muqing.state、不碰 consequence.log —— 她记住的是她认为要记的
 * 那些聊天内容的【主要意思】，不是整段聊天记录，因此清理表面记录
 * 不会顺带删掉她的记忆。
 *
 * 底部注释块在 XML 里，单独一块，不可点、不参与任何逻辑。
 */
public final class SettingsActivity extends Activity {
    private UiPrefs prefs;
    private LinearLayout container;
    private LinearLayout subList;
    private boolean shown;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new UiPrefs(this);
        setContentView(R.layout.activity_settings);
        container = findViewById(R.id.list_container);

        ((View) findViewById(R.id.btn_back)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { close(); }
        });

        final TextView toggle = new TextView(this);
        styleRow(toggle, "显示");
        container.addView(toggle);

        subList = new LinearLayout(this);
        subList.setOrientation(LinearLayout.VERTICAL);
        subList.setVisibility(View.GONE);
        container.addView(subList);

        addGroup("头像", avatarControls());
        addGroup("聊天背景", bgControls());
        addGroup("名字", nameControls());
        addGroup("气泡和颜色", bubbleColorControls());

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                shown = !shown;
                subList.setVisibility(shown ? View.VISIBLE : View.GONE);
                toggle.setText(shown ? "收起" : "显示");
            }
        });

        // 调试版专用入口：正式版没有这一行，也没有 DebugActivity
        addRow(container, getString(R.string.debug_entry), new View.OnClickListener() {
            @Override public void onClick(View v) {
                DebugLog.write("UI", "列表 → 调试日志");
                startActivity(new Intent(SettingsActivity.this, DebugActivity.class));
            }
        });

        addRow(container, "恢复全部默认（全黑）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.resetAll();
                ImagePick.clear(SettingsActivity.this, ImagePick.AVATAR_AI);
                ImagePick.clear(SettingsActivity.this, ImagePick.AVATAR_USER);
                ImagePick.clear(SettingsActivity.this, ImagePick.BG);
                ImagePick.clear(SettingsActivity.this, ImagePick.BUBBLE);
                recreate();
            }
        });

        // 唯一给用户的清理入口：点击回到聊天界面进入选择模式
        addRow(container, "清理聊天数据", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(SettingsActivity.this, MainActivity.class);
                i.putExtra("enter_cleanup", true);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            }
        });
    }

    private void addGroup(String title, final LinearLayout content) {
        final TextView row = new TextView(this);
        // 全角空格缩进保留，只去掉树形符 └ —— 缩进还在，只是不再画一棵树
        styleRow(row, "　" + title);
        subList.addView(row);
        content.setVisibility(View.GONE);
        subList.addView(content);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                content.setVisibility(content.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
    }

    private LinearLayout groupBox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(28, 6, 20, 12);
        l.setBackgroundColor(0xFFF7F7FB);
        return l;
    }

    private LinearLayout avatarControls() {
        LinearLayout l = groupBox();
        addTextRow(l, "上传 AI 头像", new View.OnClickListener() {
            @Override public void onClick(View v) { pick(ImagePick.REQ_AVATAR_AI); }
        });
        addTextRow(l, "上传 用户头像", new View.OnClickListener() {
            @Override public void onClick(View v) { pick(ImagePick.REQ_AVATAR_USER); }
        });
        return l;
    }

    private LinearLayout bgControls() {
        LinearLayout l = groupBox();
        addTextRow(l, "上传聊天背景", new View.OnClickListener() {
            @Override public void onClick(View v) { pick(ImagePick.REQ_BG); }
        });
        return l;
    }

    private LinearLayout nameControls() {
        LinearLayout l = groupBox();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final EditText edit = new EditText(this);
        edit.setText(prefs.name());
        edit.setSingleLine(true);
        edit.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        edit.setLayoutParams(lp);
        row.addView(edit);
        Button save = new Button(this);
        save.setText("保存");
        save.setTextSize(12);
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String s = edit.getText().toString().trim();
                prefs.name(s.isEmpty() ? UiPrefs.DEFAULT_NAME : s);
                Toast.makeText(SettingsActivity.this, R.string.saved, Toast.LENGTH_SHORT).show();
            }
        });
        row.addView(save);
        l.addView(row);
        return l;
    }

    /**
     * 气泡和颜色：不再让用户手输 #RRGGBB 这种字符。
     * 每一项 = 【这个颜色的一张图片】（纯色色块，实时预览）+ 【一条数轴】
     * （SeekBar，拖动即换色、即时保存）。所见即所得，不需要保存按钮。
     *
     * 这条数轴只是 UI 偏好，不进她的内部、不参与输出，和引擎的
     * 「无内置语言库 / 不预置映射」没有任何关系。
     */
    private LinearLayout bubbleColorControls() {
        LinearLayout l = groupBox();
        addTextRow(l, "上传气泡（图片 / GIF）", new View.OnClickListener() {
            @Override public void onClick(View v) { pick(ImagePick.REQ_BUBBLE); }
        });
        addColorAxis(l, "用户 气泡颜色", prefs.bubbleUser(), new ColorSink() {
            @Override public void set(int c) { prefs.bubbleUser(c); }
        });
        addColorAxis(l, "用户 文字颜色", prefs.textUser(), new ColorSink() {
            @Override public void set(int c) { prefs.textUser(c); }
        });
        addColorAxis(l, "AI 气泡颜色", prefs.bubbleAi(), new ColorSink() {
            @Override public void set(int c) { prefs.bubbleAi(c); }
        });
        addColorAxis(l, "AI 文字颜色", prefs.textAi(), new ColorSink() {
            @Override public void set(int c) { prefs.textAi(c); }
        });
        TextView note = new TextView(this);
        note.setText(R.string.color_hint);
        note.setTextSize(11);
        note.setTextColor(0xFF888899);
        note.setPadding(0, 8, 0, 0);
        l.addView(note);
        return l;
    }

    private interface ColorSink { void set(int c); }

    /** 一行颜色：标签 + 色块图片 + 数轴。色块显示的是当前真实保存的颜色。 */
    private void addColorAxis(LinearLayout parent, String label, final int current, final ColorSink sink) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(13);
        tv.setTextColor(0xFF555566);
        tv.setPadding(0, 10, 0, 0);
        parent.addView(tv);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);

        // 外框只为了让浅色色块在白底上看得见；里面那张图才是「这个颜色的图片」
        LinearLayout frame = new LinearLayout(this);
        frame.setBackgroundColor(0xFFDDDDE6);
        frame.setPadding(2, 2, 2, 2);
        final ImageView swatch = new ImageView(this);
        swatch.setImageBitmap(swatchBitmap(current));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(46, 46);
        frame.addView(swatch, sp);
        row.addView(frame);

        final SeekBar axis = new SeekBar(this);
        axis.setMax(100);
        axis.setProgress(nearestRamp(current));      // 旧配色不丢：先落到数轴上最接近的一格
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        ap.setMargins(12, 0, 0, 0);
        row.addView(axis, ap);
        parent.addView(row);

        axis.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int c = rampColor(progress);
                swatch.setImageBitmap(swatchBitmap(c));
                if (fromUser) sink.set(c);           // 拖动即时写回，不用再点保存
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
    }

    /** 数轴 0–24 是黑→白灰阶，25–100 是整圈色相。一条数轴覆盖灰度和所有彩色。 */
    private static int rampColor(int i) {
        if (i <= 24) {
            int v = Math.round(255f * i / 24f);
            return 0xFF000000 | (v << 16) | (v << 8) | v;
        }
        float h = (i - 25) * 360f / 75f;
        return Color.HSVToColor(new float[]{h, 0.85f, 0.95f});
    }

    /** 把已保存的任意颜色落到数轴上最接近的一格，避免进设置页就改掉旧配色。 */
    private static int nearestRamp(int argb) {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        int best = 0;
        long bd = Long.MAX_VALUE;
        for (int i = 0; i <= 100; i++) {
            int c = rampColor(i);
            long dr = r - ((c >> 16) & 255), dg = g - ((c >> 8) & 255), db = b - (c & 255);
            long d = dr * dr + dg * dg + db * db;
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    /** 真的生成一张「这个颜色」的图片，不是给 View 刷个背景色。 */
    private static Bitmap swatchBitmap(int color) {
        Bitmap b = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
        b.eraseColor(color);
        return b;
    }

    private void styleRow(TextView tv, String text) {
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextColor(0xFF333344);
        tv.setPadding(20, 18, 20, 18);
        tv.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 1, 0, 0);
        tv.setLayoutParams(lp);
    }

    private void addRow(LinearLayout parent, String label, View.OnClickListener action) {
        TextView tv = new TextView(this);
        styleRow(tv, label);
        tv.setOnClickListener(action);
        parent.addView(tv);
    }

    private void addTextRow(LinearLayout parent, String label, View.OnClickListener action) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF5B6ABF);
        tv.setPadding(0, 10, 0, 10);
        tv.setOnClickListener(action);
        parent.addView(tv);
    }

    private void pick(int req) { startActivityForResult(ImagePick.pick(), req); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (req == ImagePick.REQ_AVATAR_AI) {
            if (ImagePick.copy(this, uri, ImagePick.AVATAR_AI)) prefs.hasAvatarAi(true);
        } else if (req == ImagePick.REQ_AVATAR_USER) {
            if (ImagePick.copy(this, uri, ImagePick.AVATAR_USER)) prefs.hasAvatarUser(true);
        } else if (req == ImagePick.REQ_BG) {
            if (ImagePick.copy(this, uri, ImagePick.BG)) prefs.hasBg(true);
        } else if (req == ImagePick.REQ_BUBBLE) {
            if (ImagePick.copy(this, uri, ImagePick.BUBBLE)) prefs.hasBubble(true);
        }
    }

    private void close() {
        finish();
        overridePendingTransition(0, R.anim.slide_out_left);
    }

    @Override public void onBackPressed() { close(); }
}
