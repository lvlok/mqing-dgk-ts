package com.muqing.android;

import android.content.Context;

import com.muqing.core.ConsequenceLog;
import com.muqing.core.MuQing;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 非易失持久化（基底第 1 条：记忆不掉电，掉电再来电她还是她）。
 *
 * 三个空间严格分开：
 *   muqing.state      —— 记忆层 / 权重 / 偏向 / 耦合，可覆盖
 *   consequence.log   —— 后果层，append-only，只读
 *   chat.log          —— 说过的话（表面类型层），append-only，可显示
 *   alive             —— 仅在会话中存在；残留 = 上次被杀或掉电
 *
 * 后果层代码里【不读取来纠正她】，只作只读展示，保证留档连续。
 */
public final class Store {
    private final File state, log, chatLog, alive, tmp;
    private int logged;

    public Store(Context c) {
        File dir = c.getFilesDir();
        state = new File(dir, "muqing.state");
        log = new File(dir, "consequence.log");
        chatLog = new File(dir, "chat.log");
        alive = new File(dir, "alive");
        tmp = new File(dir, "muqing.state.tmp");
    }

    public MuQing load() {
        MuQing q = new MuQing();
        if (state.exists()) {
            DebugLog.write("EV", "读取 muqing.state " + state.length() + " B");
            try (DataInputStream in = new DataInputStream(new FileInputStream(state))) {
                q = MuQing.read(in);
            } catch (IOException ignored) {
                DebugLog.write("ERR", "状态损坏：按一次不可逆事件处理，不还原、不纠正");
                // 状态损坏本身就是一次不可逆事件，不悄悄还原、不纠正她
            }
        } else {
            DebugLog.write("EV", "首次运行：无状态文件，从空开始");
        }
        logged = 0;
        if (log.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(log))) {
                while (r.readLine() != null) logged++;
            } catch (IOException ignored) { }
        }
        return q;
    }

    public boolean wasInterrupted() { return alive.exists(); }
    public void markAlive() {
        try { new FileOutputStream(alive).close(); } catch (IOException ignored) { }
    }
    public void markCleanExit() { alive.delete(); }

    public void save(MuQing q) {
        try (DataOutputStream out = new DataOutputStream(new FileOutputStream(tmp))) {
            q.write(out);
        } catch (IOException ignored) { }
        if (tmp.exists()) {
            state.delete();
            tmp.renameTo(state);
            DebugLog.write("EV", "保存 muqing.state " + state.length() + " B");
        } else {
            DebugLog.write("ERR", "状态临时文件未生成，本次保存未生效");
        }
        try (FileWriter w = new FileWriter(log, true)) {
            List<ConsequenceLog.Entry> all = q.consequences().readOnly();
            for (int i = logged; i < all.size(); i++) {
                w.write(all.get(i).line());
                w.write('\n');
                logged++;
            }
        } catch (IOException ignored) { }
    }

    /** 后果层只读视图。why 列恒为 null，永不给编辑入口。 */
    public List<String> readArchive() {
        ArrayList<String> out = new ArrayList<>();
        if (!log.exists()) return out;
        try (BufferedReader r = new BufferedReader(new FileReader(log))) {
            String s;
            while ((s = r.readLine()) != null) out.add(s);
        } catch (IOException ignored) { }
        return out;
    }

    public static final class ChatLine {
        public final boolean user;
        public final String text;
        ChatLine(boolean u, String t) { user = u; text = t; }
    }

    /** 说过的话追加保存。她没发就不写任何东西 —— 沉默不产生记录。 */
    public void appendChat(String text, boolean user) {
        DebugLog.write("EV", "chat.log 追加一条 " + (user ? "用户" : "她") + " 消息");
        try (FileWriter w = new FileWriter(chatLog, true)) {
            w.write((user ? "1" : "0") + "\t" + text.replace('\t', ' ') + "\n");
        } catch (IOException ignored) { }
    }

    public List<ChatLine> readChat() {
        ArrayList<ChatLine> out = new ArrayList<>();
        if (!chatLog.exists()) return out;
        try (BufferedReader r = new BufferedReader(new FileReader(chatLog))) {
            String s;
            while ((s = r.readLine()) != null) {
                int i = s.indexOf('\t');
                if (i > 0) out.add(new ChatLine(s.charAt(0) == '1', s.substring(i + 1)));
            }
        } catch (IOException ignored) { }
        return out;
    }

    /**
     * 清理聊天数据：只重写 chat.log 的表面记录。
     *
     * 明确不碰 muqing.state，也不碰 consequence.log ——
     * 她记住的是被激活、在容量挤压后仍留存的语素（她认为要记的那些
     * 聊天内容的主要意思），不是整段聊天记录。删掉表面记录不会顺带
     * 删掉她的记忆，这两件事在文件层就是分开的。
     */
    public void deleteChatLines(java.util.Set<Integer> indices) {
        List<ChatLine> all = readChat();
        DebugLog.write("EV", "清理表面记录 " + indices.size() + "/" + all.size()
                + " 条（muqing.state / consequence.log 不动）");
        try (FileWriter w = new FileWriter(chatLog, false)) {
            for (int i = 0; i < all.size(); i++) {
                if (indices.contains(i)) continue;
                w.write((all.get(i).user ? "1" : "0") + "\t"
                        + all.get(i).text.replace('\t', ' ') + "\n");
            }
        } catch (IOException ignored) { }
    }
}
