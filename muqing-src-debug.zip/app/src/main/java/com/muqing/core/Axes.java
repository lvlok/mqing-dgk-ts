package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 三轴：从设备层状态量里【学出】三个正交方向（Oja 规则，在线主成分）。
 *
 * 方向由 B−A 给出，不由我给出：好/坏不是注入的价值观，是偏好与现实的几何关系。
 * 轴允许生长（加轴属于"改自己"→ 进后果层），但加轴不能由我发起。
 *
 * 遗留问题 2（方差最大会选中噪音）按作者决定「先不修」，此处保留定稿原样。
 */
public final class Axes {
    private final int n;
    private final double[][] a;
    private long samples;

    public Axes(int n) {
        this.n = n;
        this.a = new double[3][n];
        // 确定性正交基只是优化的起点，不是语义方向
        for (int k = 0; k < 3; k++) a[k][k % n] = 1.0;
    }

    public void learn(double[] centered) {
        samples++;
        double lr = 1.0 / (1.0 + samples);
        for (int k = 0; k < 3; k++) {
            double y = StateVector.dot(a[k], centered);
            for (int i = 0; i < n; i++) a[k][i] += lr * y * (centered[i] - y * a[k][i]);
        }
        orthonormalize();
    }

    private void orthonormalize() {
        for (int k = 0; k < 3; k++) {
            for (int m = 0; m < k; m++) {
                double d = StateVector.dot(a[k], a[m]);
                for (int i = 0; i < n; i++) a[k][i] -= d * a[m][i];
            }
            double nn = StateVector.norm(a[k]);
            if (nn > 1e-9) for (int i = 0; i < n; i++) a[k][i] /= nn;
        }
    }

    /** 误差落在三轴空间里的落点。不是格子，不贴标签。 */
    public double[] project(double[] e) {
        double[] r = new double[3];
        for (int k = 0; k < 3; k++) r[k] = StateVector.dot(a[k], e);
        return r;
    }

    /** B−A 投到轴上：指向偏好区为正向，远离为负向。符号是几何性质，不是我给的。 */
    public double[] direction(double[] B, double[] A) {
        return project(StateVector.sub(B, A));
    }

    public int count() { return 3; }
    public long samples() { return samples; }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(samples);
        for (int k = 0; k < 3; k++) for (int i = 0; i < n; i++) out.writeDouble(a[k][i]);
    }
    public static Axes read(DataInputStream in, int n) throws IOException {
        Axes ax = new Axes(n);
        ax.samples = in.readLong();
        for (int k = 0; k < 3; k++) for (int i = 0; i < n; i++) ax.a[k][i] = in.readDouble();
        return ax;
    }
}
