package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 偏向累积（基底第 3 条）。
 *
 * 0.85：B = 理想，来自偏向累积，不由预测误差学出；A = 现实；好 = 与理想偏差最小。
 * 0.86：在意 = 产生差值的访问，不是访问频率本身。功能词零差值 → 留得住但永不在意。
 *
 * 因此这里没有重要性标签、没有停用词表、没有"在意谁"的设定。
 */
public final class Bias {
    private final int n;
    private final double[] B;
    private double weight;

    public Bias(int n) { this.n = n; this.B = new double[n]; }

    /** 只在一次访问【真的产生了差值】时才累积；diff 由预测器给出，不写死阈值。 */
    public void accumulate(double[] x, double diff) {
        if (diff <= 0) return;
        weight += diff;
        for (int i = 0; i < n; i++) {
            B[i] += (x[i] - B[i]) * (diff / weight);
        }
    }

    public double[] ideal() { return StateVector.copy(B); }
    public boolean hasPreference() { return weight > 0 && StateVector.norm(B) > 0; }
    public double weight() { return weight; }

    public void write(DataOutputStream out) throws IOException {
        out.writeDouble(weight);
        for (int i = 0; i < n; i++) out.writeDouble(B[i]);
    }
    public static Bias read(DataInputStream in, int n) throws IOException {
        Bias b = new Bias(n);
        b.weight = in.readDouble();
        for (int i = 0; i < n; i++) b.B[i] = in.readDouble();
        return b;
    }
}
