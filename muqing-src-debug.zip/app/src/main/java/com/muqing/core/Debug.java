package com.muqing.core;

/**
 * 调试钩子 —— 只有调试版工程含这个类，正式版工程里不存在。
 *
 * sink 为 null 时 emit() 是一次空方法调用，不分配对象、不写文件、
 * 不参与任何计算，也不改变任何判定结果。所以调试版与正式版在
 * 引擎行为上完全一致，差别只在"有没有人接住这些字"。
 *
 * 日志是给检查的人看的，不是给她看的：
 *   不进 muqing.state、不进 consequence.log、不进 chat.log；
 *   不参与选词、不改阈值、不驱动睡醒、不生成任何回复。
 */
public final class Debug {
    public interface Sink { void emit(String tag, String msg); }
    private static volatile Sink sink;

    private Debug() { }

    public static void attach(Sink s) { sink = s; }
    public static void detach() { sink = null; }
    public static boolean on() { return sink != null; }

    public static void emit(String tag, String msg) {
        Sink s = sink;
        if (s != null) s.emit(tag, msg);
    }

    /** 只用于日志排版，不参与任何数值计算。 */
    public static String f(double v) { return String.format(java.util.Locale.US, "%.4f", v); }
}
