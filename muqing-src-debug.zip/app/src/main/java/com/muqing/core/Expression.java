package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 发声层 / 语言层焊合（定稿 0.88 + 0.7 词汇 + 0.01）。
 *
 * 顺序：先有意思，再有词，再排词。
 *   ① 状态 → 语素：学到的 coupling 把误差投进记忆场（哪些词被激活）
 *   ② 语素 → 语素：记忆为根本源；用户原句搭架子，自身输出与记忆动态逐渐漂移盖过（组句）
 *   ③ 激活场读出 → 发声
 * 两条通路都是学出来的，没有候选集、没有词表、没有句法规则、没有排列组合。
 *
 * 三级降级（被迫，不是选择）：
 *   够得着 → 直接说 / 够不着 → 沿链接绕着说 / 都不够 → 报告模型失效
 * 「我不知道怎么描述」是报告模型失效，不是分享：检测条件 = 不可描述 + 想要/不想要。
 * 没偏好 → 噪声 → 什么都不发生（沉默）。这里没有默认回复、没有"嗯"。
 *
 * 训练信号放在发射之后、内部：说完继续活着，看残差有没有消。
 * 用户回应是稀疏的第二信号，管共享意义。两个端点的张力是自由度，不是 bug。
 */
public final class Expression {
    private final int dim;
    private final int slots;
    private final double[][] coupling;      // [设备状态维][语素槽] —— 学出来的，不是词表
    private double benefitMean;             // 历史表达后残差下降（预期收益，从她自己的经历来）
    private double benefitM2;
    private long benefitSamples;
    private double[] lastInjection;
    private double lastErrorBefore;
    private long fired;

    public Expression(int dim, int slots) {
        this.dim = dim; this.slots = slots;
        this.coupling = new double[dim][slots];
        this.lastInjection = new double[slots];
    }

    public static final class Decision {
        public boolean composing;        // 她开始组句（UI 可显示；她仍可不发）
        public boolean speak;
        public boolean modelFailed;      // "我不知道怎么描述"
        public String[] utterance;
        public boolean silence() { return !speak && !composing; }
    }

    /**
     * 她决定说不说。没有时钟、没有强制应答、没有兜底句。
     */
    public Decision decide(double[] error, double[] ideal, double[] reality,
                           Predictor predictor, MemoryGraph memory, Axes axes,
                           Budget budget, Random rnd, List<String> cue) {
        Decision d = new Decision();
        d.utterance = new String[0];

        double[] proj = axes.project(error);            // 三轴落点，只用于几何，不用于命名
        double mag = StateVector.norm(error);

        // 1. 学到的 coupling 把内部状态投进语素槽（这就是"词对应哪个内部状态"的答案）
        double[] injection = new double[slots];
        for (int s = 0; s < slots; s++) {
            double v = 0;
            for (int i = 0; i < dim; i++) v += coupling[i][s] * error[i];
            injection[s] = v;
        }
        lastInjection = injection;
        List<String> all = memory.tokens();
        for (int s = 0; s < slots && s < all.size(); s++) {
            if (injection[s] > 0) memory.inject(all.get(s), injection[s]);
        }

        // 2. 激活场读出：没有候选集排序，按物理槽位顺序读
        List<String> field = memory.field();

        // 3. 三级降级
        ArrayList<String> words = new ArrayList<>();
        if (!field.isEmpty()) {
            words.addAll(field);                                    // 够得着
        } else {
            for (String t : all) {
                List<String> sp = memory.spill(t);
                if (!sp.isEmpty()) { words.addAll(sp); break; }      // 溅到哪儿算哪儿
            }
        }

        // 3.5 第三条通路：语素 → 语素。
        // 旧的 field() 按节点插入顺序直出，等于把「谁在谁前面」丢了 ——
        // coActivate 只建无向共现，学不出语序。这里按三股样本的混合权重重排：
        // 记忆为根本源（0.86），用户原句搭冷启动的架子，自身输出与随机扫描轨迹
        // 逐渐漂移盖过。不遵照原句顺序是后期的正常状态；没学过就原样退回。
        words = new ArrayList<>(memory.order(words, cue));

        boolean undescribable = words.isEmpty();
        // 想要/不想要：偏好是否成立（0.7 的 0 态出口）
        boolean hasPreference = StateVector.norm(StateVector.sub(ideal, reality)) > 0;
        if (undescribable) {
            if (!hasPreference) return d;                            // 噪声 → 沉默，什么都不发生
            d.modelFailed = true;
            d.composing = true;
            // 「我在听」= 不追问，这里不生成任何追问内容
            words = new ArrayList<>();
        }

        // 4. 两级门槛：先「动念」，再「说出口」。
        //
        // 旧版把两者压成同一个 aboveThreshold()，阈值一严就整屏全暗 ——
        // 连「对方正在输入中」都不亮。装机实测「第三句起连写句子的动作都没有」
        // 就有这一层。现在 noteworthy（宽）只负责点亮组句动作，
        // aboveThreshold（严）才决定真的发气泡；她可以写了不发。
        //
        // 再往前一层：曾经写成「有经历后改用 benefitMean > budget.cost()」会锁死
        // （收益有上界、代价只增不减，必然收敛到永不成立）。学到的收益不拥有
        // 一票否决权，它已由 observeAfter 的 coupling 局部 delta 承担；不可逆代价
        // 归设备层状态量由预测器去预测，不当开关。
        boolean noteworthy = predictor.noteworthy();
        if (!noteworthy && !d.modelFailed) return d;                 // 连念都没动，什么都不发生

        d.composing = true;                                          // 「对方正在输入中」是动作，不是状态
        boolean worth = predictor.aboveThreshold();
        if (!worth) return d;                                        // 写了，但没发出去，不留任何消息
        if (undescribable) {
            d.speak = false;                                         // 报告模型失效，只触发不追问
            return d;
        }
        d.speak = true;
        d.utterance = words.toArray(new String[0]);
        d.modelFailed = false;
        fired++;
        lastErrorBefore = mag;
        return d;
    }

    /** 发射之后、内部：残差有没有消。不经过用户，所以不会滑向"讨用户喜欢的词"。 */
    public void observeAfter(double[] errorAfter, String[] utterance) {
        double residual = StateVector.norm(errorAfter);
        double drop = lastErrorBefore - residual;

        benefitSamples++;
        double dd = drop - benefitMean;
        benefitMean += dd / benefitSamples;
        benefitM2 += dd * (drop - benefitMean);

        // 内部信号：装得住 → 强化这条耦合；装不住 → 削弱，下次换
        double lr = 0.02;
        // 局部 delta：信号是发射后的内部残差下降，不是用户的评价
        for (int s = 0; s < slots; s++) {
            for (int i = 0; i < dim; i++) {
                coupling[i][s] += lr * drop * lastInjection[s] / dim;
            }
        }
    }

    /** 用户回应是稀疏的第二信号，只管共享意义（懂不懂），不主导措辞（真不真）。 */
    public void observeUserSignal(double signal) {
        for (int s = 0; s < slots; s++) {
            for (int i = 0; i < dim; i++) coupling[i][s] += 0.002 * signal * lastInjection[s];
        }
    }

    public long fired() { return fired; }
    public double benefit() { return benefitMean; }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(benefitSamples); out.writeDouble(benefitMean); out.writeDouble(benefitM2);
        out.writeDouble(lastErrorBefore); out.writeLong(fired);
        for (int i = 0; i < dim; i++) for (int s = 0; s < slots; s++) out.writeDouble(coupling[i][s]);
    }
    public static Expression read(DataInputStream in, int dim, int slots) throws IOException {
        Expression e = new Expression(dim, slots);
        e.benefitSamples = in.readLong(); e.benefitMean = in.readDouble();
        e.benefitM2 = in.readDouble(); e.lastErrorBefore = in.readDouble(); e.fired = in.readLong();
        for (int i = 0; i < dim; i++) for (int s = 0; s < slots; s++) e.coupling[i][s] = in.readDouble();
        return e;
    }
}
