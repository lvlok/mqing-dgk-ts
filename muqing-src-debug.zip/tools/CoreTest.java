package com.muqing.core;

import java.io.*;
import java.util.Random;

/** 纯 Java 自测：核心逻辑不依赖 Android，可在本机编译运行。 */
public final class CoreTest {
    public static void main(String[] args) throws Exception {
        MuQing q = new MuQing();
        Random rnd = new Random(7);
        double err0 = 0, errN = 0;
        int spoke = 0, silence = 0;

        for (int step = 0; step < 400; step++) {
            double[] x = new double[StateVector.DIM];
            for (int i = 0; i < x.length; i++) x[i] = Math.sin(step * 0.07 + i) * 0.6 + rnd.nextGaussian() * 0.05;
            q.observeDevice(x, 0.1);
            if (step == 0) err0 = q.predictor().error();
            errN = q.predictor().error();

            if (step % 5 == 0) {
                MuQing.Result r = q.onUserInput("今天 的 云 很白 像狗");
                if (r.speak) {
                    spoke++;
                    q.afterExpression(x, 0.1);
                } else silence++;
            } else if (step % 7 == 0) {
                MuQing.Result r = q.think();
                if (r.speak) { spoke++; q.afterExpression(x, 0.1); } else silence++;
            }
        }

        // 持久化往返：记忆不掉电（基底第 1 条）
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        q.write(new DataOutputStream(bos));
        MuQing restored = MuQing.read(new DataInputStream(new ByteArrayInputStream(bos.toByteArray())));
        if (restored.memory().size() != q.memory().size()) throw new AssertionError("持久化丢失记忆");

        System.out.println("预测器误差 首/末 : " + String.format("%.4f", err0) + " / " + String.format("%.4f", errN));
        System.out.println("记忆节点 / 留档 : " + q.memory().size() + " / " + q.consequences().readOnly().size());
        System.out.println("开口 / 沉默     : " + spoke + " / " + silence);
        System.out.println("表达后收益(学到): " + String.format("%.4f", q.expression().benefit()));
        System.out.println("不可逆预算      : " + String.format("%.4f", q.budget().irreversible()));
        System.out.println("序列化往返      : OK (" + bos.size() + " bytes)");
        System.out.println("CORE OK");
    }
}
